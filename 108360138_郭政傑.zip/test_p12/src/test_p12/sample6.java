package test_p12;

import test_p12.Car;

public class sample6 {

	public static void main(String[] args) {
     Car car1 ;
     car1=new Car();
     
     car1.num =1234;
     car1.gas =20.5;

     car1.showcar();
 
	}

}
class Car
{
	int num;
	double gas;
	
	void show() {
		 System.out.println("�����O"+num);
	     System.out.println("�T�o�q�O"+gas);
	}
	void showcar() {
		
		 System.out.println("�}�l��ܨ��l���");
         this.show();
	}
}