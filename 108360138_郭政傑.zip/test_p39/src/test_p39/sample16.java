package test_p39;

public class sample16 
{
		public static void main(String[] args)
		{
         int []test =new int [5];
         test[0]=80;
         test[1]=50;
         test[2]=40;
         test[3]=78;
         test[4]=44;
         for(int i=0 ; i<=4 ; i++) 
			{

				System.out.println("��"+i+"�Ӫ��H�����ƬO"+test[i]+"��");				
			}        


		}
}
