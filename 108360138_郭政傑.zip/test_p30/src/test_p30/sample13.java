package test_p30;

public class sample13 
{
	public static void main(String[] args)
	{
		for(int i=0 ; i<=4 ; i++) 
		{
			for(int j=1 ; j<=2 ; j++)
			System.out.println("i��O"+i+" j��O"+j);
		}
	}
}
