package test_p42;

public class sample19 
{
	public static void main(String[] args)
	{
     int []test = {80,60,51,98,88};

     for(int i=0 ; i<=4 ; i++) 
		{
			System.out.println("��"+(i+1)+"�Ӫ��H�����ƬO"+test[i]+"��");				
		}        
    }
}
